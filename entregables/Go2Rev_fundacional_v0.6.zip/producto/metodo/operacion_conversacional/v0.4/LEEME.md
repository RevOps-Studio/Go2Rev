# Operación conversacional y capacidades del entorno

Versión base 0.4 · Integración del conjunto 0.6

Para empezar, instalar las [instrucciones de proyecto](INSTRUCCIONES_DE_PROYECTO.md) y usar [entrada](ENTRADA_GO2REV.md), [invariantes](13_invariantes.md), [enrutado](14_identidad_enrutado_y_retirada.md) e índice, reunidos en CARGA_INICIO. Añadir la carga del nodo y abrir los [criterios de suficiencia](12_nucleo_y_suficiencia.md) y las secciones de extensión cuando se active su condición. [Primera pasada](10_primera_pasada.md) es una vista del mapa y la [definición de campos](../../esquema/v0.1/LEEME.md).

## Instrucciones

- [Glosario de trabajo Go2Rev](00_glosario.md).
- [Guía del consultor para trabajar por conversación](01_guia_del_consultor.md).
- [Rutas de tarea y lectura selectiva](02_rutas_y_lectura.md).
- [Capacidades del entorno y alternativas suficientes](03_capacidades_y_alternativas.md).
- [Adaptar el uso al entorno sin cambiar el método](04_adaptacion_del_entorno.md).
- [Continuidad, guardado y revisión de cambios](05_continuidad_y_cambios.md).
- [Contrato de operación y revisión de operación conversacional](06_contrato_y_revision.md).
- [Carpetas y guardado del encargo](08_carpetas_y_guardado.md).
- [Poner Go2Rev a trabajar en una sesión](09_uso_por_entorno.md).
- [Primera pasada y núcleo por resultado](10_primera_pasada.md).
- [Entrada común de Go2Rev](ENTRADA_GO2REV.md).
- [Instrucciones de proyecto listas para instalar](INSTRUCCIONES_DE_PROYECTO.md).
- [Identidad, enrutado y retirada](14_identidad_enrutado_y_retirada.md).

## Plantillas

- [Plantilla de capacidad del entorno](plantillas/01_capacidad_del_entorno.md).
- [Plantilla de continuidad de tarea](plantillas/02_continuidad_de_tarea.md).
- [Plantilla de traspaso de contexto o medio](plantillas/03_traspaso_de_contexto.md).

Usar los bloques necesarios para el resultado y ampliar cuando se active una condición material. Agrupar metadatos comunes y referenciarlos desde los bloques. El contenido propio se conserva fuera de la biblioteca general.

- [Correspondencia con el vocabulario del cliente](11_correspondencia_de_vocabulario.md)

- [Núcleo de trabajo y suficiencia para decidir](12_nucleo_y_suficiencia.md)
