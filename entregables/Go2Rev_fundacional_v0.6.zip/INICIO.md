# Go2Rev Base fundacional 0.6

Abrir el [paquete y guía de implementación](producto/paquete_fundacional/v0.6/LEEME.md). La base está construida y conserva su estado teórico. La primera aplicación y sus comprobaciones requieren un ámbito autorizado.

La carpeta producto contiene las fuentes, plantillas vacías, libro editable y vistas de lectura. Herramientas contiene los generadores opcionales; no hace falta ejecutarlos para leer o utilizar el método. El inventario y manifiesto están junto a la guía del paquete.
