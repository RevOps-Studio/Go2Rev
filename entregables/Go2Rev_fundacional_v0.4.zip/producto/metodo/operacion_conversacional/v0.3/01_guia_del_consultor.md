# Guía del consultor para trabajar por conversación

Versión 0.1 · Uso común de Go2Rev

## Qué debe poder dirigir el consultor

El consultor formula una decisión, una entrega o un cambio en lenguaje natural. El asistente identifica la capacidad necesaria, lee sus instrucciones, investiga, calcula y redacta. Devuelve recomendación y material revisable con fundamento, carencias y siguiente compromiso. No hace falta conocer nombres de archivos, códigos ni comandos para pedir trabajo; esos elementos permiten conservar la trazabilidad detrás de la conversación.

La prestación comienza desde un encargo delimitado. Si mercado o segmento deben determinarse mediante Diagnostic, no se exigen resueltos de antemano. Si aún se está preparando el encargo, N01 permite definir ámbito, valor de la evaluación, salida y autoridad sin fingir que la contratación ya existe.

## Preparar el trabajo con un asistente

1. Proporcionar la [entrada común](ENTRADA_GO2REV.md) y acceso a las fuentes actuales del método, con su estructura o un índice que resuelva los localizadores. No basta un resumen que nombre los nodos.
2. Identificar la ubicación autorizada del encargo y sus materiales, si existe. El asistente comprueba qué puede recuperar y prepara el trabajo de N01/N02 que falte; no exige volver a cumplimentar lo ya disponible.
3. Identificar resultado y destinatario. La conversación puede pedir analizar, recomendar, redactar, corregir, explicar, preparar una decisión, materializar o revisar una entrega. Si la petición implica un efecto externo, su autoridad se trata por separado del borrador.
4. Dejar que el asistente proponga lecturas/acciones y produzca lo autorizado. El consultor interviene en decisiones de alcance, interpretación o compromiso que le correspondan. Una condición de exclusiva competencia del cliente o del propietario del medio debe confirmarse con esa persona; el asistente no la suple con una estimación arbitraria.

Las capacidades del entorno se comprueban para la tarea. No se necesita instalar una herramienta por cada nodo ni conectar sistemas antes de poder analizar. Si el entorno no permite guardar, puede preparar contenido completo y una instrucción de guardado; si no puede leer una fuente necesaria, debe mostrar el efecto y la alternativa. El esfuerzo de configuración debe estar justificado por el uso.

## Cómo interpretar una respuesta

| Lo que entrega el asistente | Qué debe permitir evaluar |
|---|---|
| Resultado y contexto | Qué decisión aborda, para quién, en qué ámbito y cómo se conecta con el sistema comercial |
| Fundamento | Qué viene de originales, declaraciones o inferencias; evidencia contraria y comparabilidad |
| Recomendación | Por qué se prefiere una opción, qué implica y qué la haría cambiar |
| Material editable | Contenido utilizable, fuente/revisión y condición de recepción, no solo títulos por completar |
| Carencia | Campo/pregunta exactos, consecuencia, quién puede resolverla y trabajo que puede seguir |
| Estado | Qué se redactó, guardó, configuró, comprobó o recibió realmente |

El consultor puede corregir un hecho, cuestionar el razonamiento o cambiar el compromiso. El asistente debe distinguirlos: una corrección factual necesita revisar dependencias; una decisión de adoptar una opción no demuestra que sus hipótesis sean ciertas. Pedir una explicación no debería modificar documentos por sí solo; aceptar una propuesta puede habilitar el trabajo que estaba claramente incluido en ella, sin autorización genérica para otras acciones.

## Momentos de decisión y autonomía

Diagnostic entrega una recomendación y su salida según K01. El diseño que se autoriza preparar define compromisos y recursos. La recepción contrasta lo efectivamente entregado con lo contratado. Estos momentos no exigen una reunión ni una aprobación por nodo. La lectura, producción y corrección autorizadas continúan entre ellos.

El asistente prepara una decisión concreta antes de pedirla: opción recomendada, alternativa, efecto, coste/permiso conocidos o pendientes y alcance que quedaría habilitado. Las preguntas son selectivas y comprensibles. El consultor no debe completar un cuestionario universal, reconstruir una fuente o resolver los cálculos del método para que el trabajo avance.

El resultado puede limitar una recomendación, devolver una premisa o proponer salida. La ausencia de evidencia no obliga a una conclusión favorable ni a bloquear cada campo independiente. En A se conserva la diferencia entre conocimiento de origen y transferibilidad a destino; en B entre intención, representación y capacidad efectiva.

## Continuar y recibir

Al reanudar, el asistente recupera el índice actual, decisión, artefactos y pendiente pertinente. Confirma brevemente lo necesario para orientar el trabajo y continúa; no repite la recuperación por cambio de sesión. Si una ubicación o permiso cambió, explica la limitación concreta y resuelve lo independiente.

Al recibir un entregable, el consultor debe poder localizar fuente, versión, condiciones y siguiente tarea sin leer todo el chat. El formato humano se adapta a finalidad: análisis argumentado, material de uso o síntesis para decidir. La fuente editable conserva autoridad sobre sus vistas. La [transferencia N17](../../medicion_preparacion_y_transferencia/v0.1/06_transferencia_y_cierre.md) mantiene acceso, recepción, pendientes y finalización del soporte.

Esta guía también puede usarse sin LLM: el consultor selecciona la tarea en el mapa, aplica la instrucción sustantiva y conserva los mismos contratos. El asistente acelera el trabajo disponible; no es una dependencia para usar los entregables ya recibidos.
