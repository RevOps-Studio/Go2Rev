# Plantilla · Capacidades de una nueva iniciativa

Versión de plantilla 0.1 · Recorrido B · Campos de prestación vacíos

Usar con [N02, recorrido B](../02_conocimiento_y_solicitud.md). Repetir el bloque para una capacidad material necesaria. El asistente descompone la representación de oferta; el responsable aporta fundamento de disponibilidad; el consultor revisa la relación entre capacidad y compromiso. La matriz mantiene separadas intención, representación y habilitación.

La cobertura considera acceso/compra, preparación, entrega, aceptación, cobro y continuidad comprometida. El alcance de K01 determina qué tareas son necesarias. No se atribuye preparación efectiva por haber redactado una instrucción o disponer nominalmente de un activo.

## Capacidad y requisito · Requerido en cada CAP

| Campo | Regla | Valor |
|---|---|---|
| ID, revisión, autor y fecha | Identidad estable CAP y contenido | |
| Encargo y conocimiento | K01/K02 y revisiones pertinentes | |
| Promesa y tarea que requiere capacidad | Parte de la representación de oferta que debe poder cumplirse | |
| Capacidad necesaria | Acción, resultado controlable y condición de aceptación | |
| Recurso indispensable | Persona, medio, insumo, permiso o dependencia; relación con la tarea | |
| Responsable de disponibilidad | Rol/persona con capacidad para aportar o habilitar | |
| Unidad, periodo y restricciones | Dedicación, cantidad, calendario, concurrencia y condiciones de uso pertinentes | |

## Disponibilidad y habilitación

| Campo | Regla | Valor |
|---|---|---|
| Estado de disponibilidad | Acreditada para uso delimitado; declarada pendiente de contraste; por habilitar; desconocida | |
| Fundamento | AF/FUE y revisión; alcance de lo que demuestra, HUE si falta | |
| Diferencia entre intención y disponibilidad | Qué falta para poder cumplir la tarea en el periodo requerido | |
| Condición de habilitación | Acción, recurso y criterio que permitirían disponer de ella | |
| Dependencias previas | Otras CAP, decisiones, accesos o aportaciones; momento necesario | |
| Alternativas de habilitación | Opciones materiales comparadas por adecuación, esfuerzo, coste, dependencia y reversibilidad | |
| Economía pertinente | Coste, unidad/periodo y fundamento o desconocido; referencia a N11/N12 para modelización | |
| Opción recomendada y razón | Propuesta del consultor con alternativas y limitaciones; DEC si necesita compromiso | |
| Responsable y evento límite | Quién habilita/obtiene evidencia y antes de qué uso | |

Los campos de habilitación y alternativas se requieren cuando la capacidad no esté acreditada para el uso dependiente; si no aplican, se justifica con el fundamento de disponibilidad. Su coste no se completa con cero por quedar fuera de una factura.

## Consecuencia y recepción

| Campo | Regla | Valor |
|---|---|---|
| Consumidor y compromiso | N06/N08–N12/N14, campo y revisión que necesitan la capacidad | |
| Uso permitido | Exploración, diseño condicionado u operación delimitada, según su fundamento | |
| Efecto de ausencia | Qué entrega, inicio o promesa queda limitado y qué trabajo puede continuar | |
| Evidencia pendiente | HUE/SOL o necesidad de protocolo en N14; no atribuye ejecución | |
| Revisión y autoridad | Consultor revisa; DEC identifica quien autoriza recursos/compromisos cuando corresponda | |
| Condición de reapertura | Cambio de recurso, plazo, dependencia, tarea o promesa que afecta disponibilidad | |
