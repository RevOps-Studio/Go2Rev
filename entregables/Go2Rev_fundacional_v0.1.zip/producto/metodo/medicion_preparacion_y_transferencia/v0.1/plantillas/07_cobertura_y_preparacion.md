# Plantilla de cobertura y estado de preparación

Versión 0.1 · K16 para K17 · Campos empresariales vacíos

Usar con [comprobación de preparación](../05_comprobacion_de_preparacion.md). Repetir por obligación/recorrido y conservar la relación entre criterios, observaciones y conclusión. Una proporción de filas cumplidas no compensa una obligación esencial sin cubrir.

| Campo | Regla | Valor |
|---|---|---|
| Referencia | K16/sección/revisión, autor, fecha, ubicación y estado documental | |
| Encargo | K01/revisión, entrega/obligación y condición de recepción | |
| Tarea y recorrido | Situación, decisión, acción, registro y receptor; variantes pertinentes | |
| Criticidad | Consecuencia de fallo o ausencia para el compromiso, no puntuación por facilidad | |
| Condiciones cubiertas | Dominio normal y excepciones materiales seleccionadas con motivo | |
| Material y medio | K15/regla/revisión, entorno y disponibilidad requeridos | |
| Operador y receptor | Rol/persona/capacidad a observar y ayuda ordinaria prevista | |
| Tipo de evidencia | Contenido/archivo, cálculo, captura, uso/traspaso o evidencia de mercado separada | |
| Protocolo y criterio | K14/revisión y condición previa específica | |
| Estado observado | Resultado/localizador de cada criterio, fecha/contexto y límites | |
| Carencia de cobertura | Tarea, variante, condición o capacidad no observada; motivo y efecto | |
| Defecto pendiente | Causa/productor, uso limitado y condición de corrección | |
| Reutilización | Qué observación previa se conserva y por qué equivale para este uso | |
| Conclusión por ámbito | Diseñado, preparado o comprobado según evidencia; parcial/condicionado si procede | |
| Alcance no acreditado | Qué no puede extenderse a otros medios, operadores, volumen, variantes o resultados comerciales | |
| Preparación para recepción | Obligaciones recibibles y límites que N17 debe comunicar | |
| Decisión y siguiente acción | Consultor evalúa; autoridad/receptor según K01; responsable y condición posterior | |
| Cambio y conservación | CAM pertinente, versiones originales y cobertura que requiere nueva comprobación | |

Si falta operador o recorrido crítico, la preparación del ámbito dependiente permanece parcial. Una actuación real observada tiene su alcance propio y no sustituye esta cobertura.
