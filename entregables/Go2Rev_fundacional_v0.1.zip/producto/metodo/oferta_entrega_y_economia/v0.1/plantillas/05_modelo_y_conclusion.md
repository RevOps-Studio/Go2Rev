# Plantilla · K12 Modelo y conclusión

Versión 0.1 · [Instrucción](../03_economia_y_capacidad.md) · [Guía del libro](../08_guia_del_modelo.md)

| Campo | Regla | Valor |
|---|---|---|
| Cabecera | K12, K01, revisión, autor/fecha, ámbito, estado y ubicación | |
| Pregunta y uso | Decisión y compromiso, E/O y límites | |
| Combinación | K06/revisión/sección; K08/K09/K10/K11 y campos compatibles | |
| Perímetro | Iniciativa, prestación de Go2Rev o desarrollo separados | |
| Unidades y conversión | Venta, producción, entrega, reconocimiento, facturación y cobro | |
| Periodo y moneda | Calendario, horizonte, escala, conversión y fuentes | |
| Base económica | Reconocimiento, impuestos, inclusiones/exclusiones y responsable | |
| Variantes pertinentes | Modelo de oferta/canal y relación resuelta, desconocida o no aplicable justificada | |
| Fuente editable | Archivo, revisión, hojas/celdas o secciones y motor empleado | |
| Parámetros | Valor/desconocido, unidad, AF/FUE y transformación por entrada material | |
| Cobertura de costes | Variables, comerciales/cohortes, fijos, lotes/escalones, inversión y no duplicación | |
| Capacidad | Recursos indispensables, cargas, disponibilidad/calendario y restricciones | |
| Caja | Eventos/fechas, saldo inicial, reserva, financiación y cobertura | |
| Fórmulas y dominio | Relaciones, supuestos de validez y dependencias | |
| Resultados | Contribución, resultado pertinente, equilibrio, capacidad y caja calculables | |
| No calculable o parcial | Entrada ausente/ inválida y magnitud/decisión limitada | |
| Contraste externo/interno | AF, comparabilidad, conclusión derivada y parámetro/relación afectada | |
| Comparación | Referencia a configuraciones y versiones, efectos y umbral | |
| Recomendación | Decisión propuesta, fundamento, restricciones y condición contraria | |
| Evidencia requerida | Pregunta, fuente/actuación pertinente, responsable, HUE/SOL o N14 | |
| Autoridad y disposición | DEC para inversión/riesgo/compromiso; revisión de consultor separada | |
| Consumo y revisión | Campo/versión/receptor/uso/admisión, disparador y CAM | |
