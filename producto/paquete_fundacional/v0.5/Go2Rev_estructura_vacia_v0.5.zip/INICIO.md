# Estructura vacía del encargo

Extraer dentro de la raíz acordada, separada de la biblioteca Go2Rev. Recuperar el índice si existe trabajo previo y conciliar las rutas antes de incorporar esta estructura; conservar los archivos existentes.

Completar el índice cuando exista mandato y contenido. Crear Fuentes y Lectura al producir la primera pieza de ese tipo. Seguir carpetas y guardado del conjunto 0.5.
