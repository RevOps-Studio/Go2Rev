# Estructura vacía del encargo

Extraer dentro de la raíz acordada de un nuevo encargo, separada de la biblioteca Go2Rev. Si existe trabajo previo, recuperar su índice y conciliar la correspondencia de carpetas antes de incorporar esta estructura; no sobrescribir archivos existentes.

Completar el índice cuando exista mandato y contenido. Crear Fuentes y Lectura en los conjuntos de Entregables y en Operacion al producir la primera pieza de ese tipo. Seguir carpetas y guardado en el paquete Go2Rev 0.2. Esta estructura contiene instrucciones y campos vacíos.
